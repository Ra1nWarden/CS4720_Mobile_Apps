//
//  3DViewController.swift
//  NickZihaoProject
//
//  Created by Nicholas Milef on 10/28/15.
//  Copyright © 2015 Nick&Zihao. All rights reserved.
//

import UIKit
import GLKit

class 3DViewController: GLKViewController {
    
    override func viewDidLoad() {
    }
    
    override func viewDidUnload() {
    }
}