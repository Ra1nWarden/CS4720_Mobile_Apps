//
//  TDViewController.swift
//  NickZihaoProject
//
//  Created by Nicholas Milef on 10/28/15.
//  Copyright © 2015 Nick&Zihao. All rights reserved.
//

import Foundation
import GLKit

class TDViewController: GLKViewController {
    
    
    override func viewDidLoad() {
        var view=GLKView();
        view.context=EAGLContext(API: EAGLRenderingAPI.OpenGLES2);
        
    }
    
    func 

}